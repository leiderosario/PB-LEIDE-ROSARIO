select * 
from livro
where publicacao >'2014-12-31'
order by cod asc