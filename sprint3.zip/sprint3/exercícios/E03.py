# Escreva um código Python para imprimir os números pares de 0 até 20 (incluso).
# Importante: Aplique a função range() em seu código.

for num in range(0,21,2):
    print(num)