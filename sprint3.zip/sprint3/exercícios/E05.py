# Escreva um código Python que declara 3 variáveis:
# dia, inicializada com valor 22
# mes, inicializada com valor 10 e
# ano, inicializada com valor 2022
# Como saída, você deverá imprimir a data correspondente, no formato a seguir dia/mes/ano.


dia = 22
mes = 10
ano = 2022

print(f"{dia}/{mes}/{ano}")